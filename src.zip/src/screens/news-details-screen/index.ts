export { NewsDetailsScreen } from './news-details-screen';
