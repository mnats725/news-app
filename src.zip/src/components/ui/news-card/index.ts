export { NewsCard } from './news-card';
