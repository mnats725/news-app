export const NEWS_API_BASE_URL = 'https://newsapi.org/v2';
export const NEWS_API_KEY = '4a381b113f8845cbb28eb89e12e80d77';
export const PAGE_SIZE = 10;
export const DEFAULT_COUNTRY = 'gb';

export type UiCategory = 'technology' | 'sports' | 'politics';
