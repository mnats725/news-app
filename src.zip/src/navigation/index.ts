export { RootNavigator } from './root-navigator';
